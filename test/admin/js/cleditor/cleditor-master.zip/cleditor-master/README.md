This cleditor github organization is somewhat abandoned at the moment.
If anyone would like to take over and coordinate development, I'd
happily hand over the keys.  cleditor represents a sane, tight approach
to HTML editing so it would be great to see it thrive.

The original cleditor project can still be found at
http://premiumsoftware.net/cleditor/

--------

```
I was just wondering why you abandoned the cleditor project on github, there
are 2 more pull requests one at least seems to fix an issue.

Cheers
Lukas Oppermann
```

```
Hi Lukas.  I was hoping that all the patches flowing over the mailing list
would coalesce on github and things would progress without taking as much of
Chris's time.

At the time, few people seemed to care.  Then I stopped using cleditor altogether.

If you'd like to revive it and give it active stewardship, I'm happy to hand
over the passwords.  Even though I'm not using html editors anymore, I'd love
to see a cleditor revival.  :)

    - Scott
```

```
Ahh, I see. I would like to do it, but I am not that good in javascript, I
couldn't really say which one is a good pull and which one is not.

There is no successor to cleditor, is there? Some very similar project that is
still maintained.
```

```
AFAICT html editing is still dismal.

There's gigantic, overbearing CKeditor of course.  And then there's Aloha that
looks pretty slick but has licensing that I couldn't use in my commercial
projects.  And both of those are still a little buggy -- they just don't feel
as natural as, say, using Word.

I guess that's why everybody has converted to Markdown.

    - Scott
```

```
Yeah, CKeditor is just so freaking slow. I like the fast and reduced approach
of cleditor.

Markdown is nice, but it does not work for clients I feel. They rather use a
"word-like" editor.
```

I totally agree.
